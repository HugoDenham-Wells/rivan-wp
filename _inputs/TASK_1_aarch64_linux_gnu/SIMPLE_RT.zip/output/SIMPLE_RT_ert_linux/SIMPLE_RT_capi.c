/*
 * File: SIMPLE_RT_capi.c
 *
 * Code generated for Simulink model 'SIMPLE_RT'.
 *
 * Model version                  : 1.88
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Thu Jun 12 14:38:42 2025
 *
 * Target selection: ert_linux.tlc
 * Embedded hardware selection: ARM Compatible->ARM 8
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "SIMPLE_RT_capi_host.h"
#define sizeof(...)                    ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "SIMPLE_RT.h"
#include "SIMPLE_RT_capi.h"
#include "SIMPLE_RT_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 0, TARGET_STRING("SIMPLE_RT/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 0, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 2, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 3, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("Bias"), 0, 0, 0 },

  { 4, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("Frequency"), 0, 0, 0 },

  { 5, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("Phase"), 0, 0, 0 },

  { 6, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("SinH"), 0, 0, 0 },

  { 7, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("CosH"), 0, 0, 0 },

  { 8, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("SinPhi"), 0, 0, 0 },

  { 9, TARGET_STRING("SIMPLE_RT/Sine Wave"),
    TARGET_STRING("CosPhi"), 0, 0, 0 },

  { 10, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("Amplitude"), 0, 0, 0 },

  { 11, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("Bias"), 0, 0, 0 },

  { 12, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("Frequency"), 0, 0, 0 },

  { 13, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("Phase"), 0, 0, 0 },

  { 14, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("SinH"), 0, 0, 0 },

  { 15, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("CosH"), 0, 0, 0 },

  { 16, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("SinPhi"), 0, 0, 0 },

  { 17, TARGET_STRING("SIMPLE_RT/Sine Wave1"),
    TARGET_STRING("CosPhi"), 0, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static const rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Root Inputs information */
static const rtwCAPI_Signals rtRootInputs[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

/* Root Outputs information */
static const rtwCAPI_Signals rtRootOutputs[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 18, 0, TARGET_STRING("SIMPLE_RT/Q_1"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 19, 0, TARGET_STRING("SIMPLE_RT/Q_2"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &SIMPLE_RT_B.Product,                /* 0: Signal */
  &SIMPLE_RT_B.SineWave,               /* 1: Signal */
  &SIMPLE_RT_P.SineWave_Amp,           /* 2: Block Parameter */
  &SIMPLE_RT_P.SineWave_Bias,          /* 3: Block Parameter */
  &SIMPLE_RT_P.SineWave_Freq,          /* 4: Block Parameter */
  &SIMPLE_RT_P.SineWave_Phase,         /* 5: Block Parameter */
  &SIMPLE_RT_P.SineWave_Hsin,          /* 6: Block Parameter */
  &SIMPLE_RT_P.SineWave_HCos,          /* 7: Block Parameter */
  &SIMPLE_RT_P.SineWave_PSin,          /* 8: Block Parameter */
  &SIMPLE_RT_P.SineWave_PCos,          /* 9: Block Parameter */
  &SIMPLE_RT_P.SineWave1_Amp,          /* 10: Block Parameter */
  &SIMPLE_RT_P.SineWave1_Bias,         /* 11: Block Parameter */
  &SIMPLE_RT_P.SineWave1_Freq,         /* 12: Block Parameter */
  &SIMPLE_RT_P.SineWave1_Phase,        /* 13: Block Parameter */
  &SIMPLE_RT_P.SineWave1_Hsin,         /* 14: Block Parameter */
  &SIMPLE_RT_P.SineWave1_HCos,         /* 15: Block Parameter */
  &SIMPLE_RT_P.SineWave1_PSin,         /* 16: Block Parameter */
  &SIMPLE_RT_P.SineWave1_PCos,         /* 17: Block Parameter */
  &SIMPLE_RT_Y.Q_1,                    /* 18: Root Output */
  &SIMPLE_RT_Y.Q_2,                    /* 19: Root Output */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), (uint8_T)SS_DOUBLE, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1                                    /* 1 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.05, 0.0
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, (boolean_T)0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    (int8_T)0, (uint8_T)0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 2,
    rtRootInputs, 0,
    rtRootOutputs, 2 },

  { rtBlockParameters, 16,
    rtModelParameters, 0 },

  { rtBlockStates, 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 1807776314U,
    4150173325U,
    3634272898U,
    3980045516U },
  (NULL), 0,
  (boolean_T)0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  SIMPLE_RT_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void SIMPLE_RT_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(SIMPLE_RT_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(SIMPLE_RT_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(SIMPLE_RT_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(SIMPLE_RT_M->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(SIMPLE_RT_M->DataMapInfo.mmi, rtVarDimsAddrMap);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(SIMPLE_RT_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(SIMPLE_RT_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(SIMPLE_RT_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C"
{

#endif

  void SIMPLE_RT_host_InitializeDataMapInfo(SIMPLE_RT_host_DataMapInfo_T
    *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, (NULL));

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, (NULL));

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, (NULL));

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}

#endif
#endif                                 /* HOST_CAPI_BUILD */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
