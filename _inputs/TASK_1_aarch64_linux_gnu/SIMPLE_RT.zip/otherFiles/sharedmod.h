#ifndef SHAREDMOD_H
#define SHAREDMOD_H

#include "nanomodbus.h"

#define EXPORT __attribute__((visibility("default")))

#define SHARED_CLIENT_MAX_CLIENTS 16

typedef enum
{
  SHARED_CLIENT_OOR = -1,
  SHARED_CLIENT_OK = 0,
} SHARED_CLIENT_RES_T;

typedef enum
{
  CLIENT_STATUS_ERROR_OOR = -6,
  CLIENT_STATUS_ERROR = -5,
  CLIENT_STATUS_UINIT = -4,
  CLIENT_STATUS_OFFLINE = -3,
  CLIENT_STATUS_CONNECTING = -2,
  CLIENT_STATUS_OK = 0,
  CLIENT_STATUS_DISABLED = 1,
} CLIENT_STATUS_T;

typedef  enum {
  MODBUS_STATUS_ERROR_OOR = -6,
  MODBUS_STATUS_CLIENT_ERR = -5,
  MODBUS_STATUS_OK = 0,
  MODBUS_STATUS_DISABLED = 1
} MODBUS_STATUS_T;

EXPORT SHARED_CLIENT_RES_T get_client_connections(uint8_T id, int **conn);
EXPORT SHARED_CLIENT_RES_T get_platform_config(uint8_T id, nmbs_platform_conf **platform_config);
EXPORT SHARED_CLIENT_RES_T get_status(uint8_T id, CLIENT_STATUS_T **status);
EXPORT SHARED_CLIENT_RES_T get_nmbs(uint8_T id, nmbs_t **nmbs);
EXPORT SHARED_CLIENT_RES_T get_status(uint8_T id, CLIENT_STATUS_T **status);

#endif 
