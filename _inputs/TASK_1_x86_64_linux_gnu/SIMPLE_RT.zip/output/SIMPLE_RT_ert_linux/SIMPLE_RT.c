/*
 * File: SIMPLE_RT.c
 *
 * Code generated for Simulink model 'SIMPLE_RT'.
 *
 * Model version                  : 1.88
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Thu Jun 12 14:33:35 2025
 *
 * Target selection: ert_linux.tlc
 * Embedded hardware selection: ARM Compatible->ARM 8
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SIMPLE_RT.h"
#include <math.h>
#include "rtwtypes.h"
#include <string.h>
#include "SIMPLE_RT_capi.h"
#include "SIMPLE_RT_private.h"

/* Block signals (default storage) */
B_SIMPLE_RT_T SIMPLE_RT_B;

/* Block states (default storage) */
DW_SIMPLE_RT_T SIMPLE_RT_DW;

/* External outputs (root outports fed by signals with default storage) */
ExtY_SIMPLE_RT_T SIMPLE_RT_Y;

/* Real-time model */
static RT_MODEL_SIMPLE_RT_T SIMPLE_RT_M_;
RT_MODEL_SIMPLE_RT_T *const SIMPLE_RT_M = &SIMPLE_RT_M_;

/* Model step function */
void SIMPLE_RT_step(void)
{
  real_T lastSin_tmp;

  /* Sin: '<Root>/Sine Wave' */
  if (SIMPLE_RT_DW.systemEnable != 0) {
    lastSin_tmp = SIMPLE_RT_P.SineWave_Freq * SIMPLE_RT_M->Timing.taskTime0;
    SIMPLE_RT_DW.lastSin = sin(lastSin_tmp);
    SIMPLE_RT_DW.lastCos = cos(lastSin_tmp);
    SIMPLE_RT_DW.systemEnable = 0;
  }

  /* Sin: '<Root>/Sine Wave' */
  SIMPLE_RT_B.SineWave = ((SIMPLE_RT_DW.lastSin * SIMPLE_RT_P.SineWave_PCos +
    SIMPLE_RT_DW.lastCos * SIMPLE_RT_P.SineWave_PSin) *
    SIMPLE_RT_P.SineWave_HCos + (SIMPLE_RT_DW.lastCos *
    SIMPLE_RT_P.SineWave_PCos - SIMPLE_RT_DW.lastSin * SIMPLE_RT_P.SineWave_PSin)
    * SIMPLE_RT_P.SineWave_Hsin) * SIMPLE_RT_P.SineWave_Amp +
    SIMPLE_RT_P.SineWave_Bias;

  /* Outport: '<Root>/Q_1' */
  SIMPLE_RT_Y.Q_1 = SIMPLE_RT_B.SineWave;

  /* Sin: '<Root>/Sine Wave1' */
  if (SIMPLE_RT_DW.systemEnable_l != 0) {
    lastSin_tmp = SIMPLE_RT_P.SineWave1_Freq * SIMPLE_RT_M->Timing.taskTime0;
    SIMPLE_RT_DW.lastSin_m = sin(lastSin_tmp);
    SIMPLE_RT_DW.lastCos_j = cos(lastSin_tmp);
    SIMPLE_RT_DW.systemEnable_l = 0;
  }

  /* Product: '<Root>/Product' incorporates:
   *  Sin: '<Root>/Sine Wave1'
   */
  SIMPLE_RT_B.Product = (((SIMPLE_RT_DW.lastSin_m * SIMPLE_RT_P.SineWave1_PCos +
    SIMPLE_RT_DW.lastCos_j * SIMPLE_RT_P.SineWave1_PSin) *
    SIMPLE_RT_P.SineWave1_HCos + (SIMPLE_RT_DW.lastCos_j *
    SIMPLE_RT_P.SineWave1_PCos - SIMPLE_RT_DW.lastSin_m *
    SIMPLE_RT_P.SineWave1_PSin) * SIMPLE_RT_P.SineWave1_Hsin) *
    SIMPLE_RT_P.SineWave1_Amp + SIMPLE_RT_P.SineWave1_Bias) *
    SIMPLE_RT_B.SineWave;

  /* Outport: '<Root>/Q_2' */
  SIMPLE_RT_Y.Q_2 = SIMPLE_RT_B.Product;

  /* Update for Sin: '<Root>/Sine Wave' */
  lastSin_tmp = SIMPLE_RT_DW.lastSin;
  SIMPLE_RT_DW.lastSin = SIMPLE_RT_DW.lastSin * SIMPLE_RT_P.SineWave_HCos +
    SIMPLE_RT_DW.lastCos * SIMPLE_RT_P.SineWave_Hsin;
  SIMPLE_RT_DW.lastCos = SIMPLE_RT_DW.lastCos * SIMPLE_RT_P.SineWave_HCos -
    lastSin_tmp * SIMPLE_RT_P.SineWave_Hsin;

  /* Update for Sin: '<Root>/Sine Wave1' */
  lastSin_tmp = SIMPLE_RT_DW.lastSin_m;
  SIMPLE_RT_DW.lastSin_m = SIMPLE_RT_DW.lastSin_m * SIMPLE_RT_P.SineWave1_HCos +
    SIMPLE_RT_DW.lastCos_j * SIMPLE_RT_P.SineWave1_Hsin;
  SIMPLE_RT_DW.lastCos_j = SIMPLE_RT_DW.lastCos_j * SIMPLE_RT_P.SineWave1_HCos -
    lastSin_tmp * SIMPLE_RT_P.SineWave1_Hsin;

  /* External mode */
  rtExtModeUploadCheckTrigger(1);

  {                                    /* Sample time: [0.05s, 0.0s] */
    rtExtModeUpload(0, (real_T)SIMPLE_RT_M->Timing.taskTime0);
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.05s, 0.0s] */
    if ((rtmGetTFinal(SIMPLE_RT_M)!=-1) &&
        !((rtmGetTFinal(SIMPLE_RT_M)-SIMPLE_RT_M->Timing.taskTime0) >
          SIMPLE_RT_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(SIMPLE_RT_M, "Simulation finished");
    }

    if (rtmGetStopRequested(SIMPLE_RT_M)) {
      rtmSetErrorStatus(SIMPLE_RT_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  SIMPLE_RT_M->Timing.taskTime0 =
    ((time_T)(++SIMPLE_RT_M->Timing.clockTick0)) * SIMPLE_RT_M->Timing.stepSize0;
}

/* Model initialize function */
void SIMPLE_RT_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)SIMPLE_RT_M, 0,
                sizeof(RT_MODEL_SIMPLE_RT_T));
  rtmSetTFinal(SIMPLE_RT_M, -1);
  SIMPLE_RT_M->Timing.stepSize0 = 0.05;

  /* External mode info */
  SIMPLE_RT_M->Sizes.checksums[0] = (1807776314U);
  SIMPLE_RT_M->Sizes.checksums[1] = (4150173325U);
  SIMPLE_RT_M->Sizes.checksums[2] = (3634272898U);
  SIMPLE_RT_M->Sizes.checksums[3] = (3980045516U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    SIMPLE_RT_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(SIMPLE_RT_M->extModeInfo,
      &SIMPLE_RT_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(SIMPLE_RT_M->extModeInfo, SIMPLE_RT_M->Sizes.checksums);
    rteiSetTPtr(SIMPLE_RT_M->extModeInfo, rtmGetTPtr(SIMPLE_RT_M));
  }

  /* block I/O */
  (void) memset(((void *) &SIMPLE_RT_B), 0,
                sizeof(B_SIMPLE_RT_T));

  /* states (dwork) */
  (void) memset((void *)&SIMPLE_RT_DW, 0,
                sizeof(DW_SIMPLE_RT_T));

  /* external outputs */
  (void)memset(&SIMPLE_RT_Y, 0, sizeof(ExtY_SIMPLE_RT_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  SIMPLE_RT_InitializeDataMapInfo();

  /* Enable for Sin: '<Root>/Sine Wave' */
  SIMPLE_RT_DW.systemEnable = 1;

  /* Enable for Sin: '<Root>/Sine Wave1' */
  SIMPLE_RT_DW.systemEnable_l = 1;
}

/* Model terminate function */
void SIMPLE_RT_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
