/*
 * File: SIMPLE_RT_capi.h
 *
 * Code generated for Simulink model 'SIMPLE_RT'.
 *
 * Model version                  : 1.88
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Thu Jun 12 14:33:35 2025
 *
 * Target selection: ert_linux.tlc
 * Embedded hardware selection: ARM Compatible->ARM 8
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef SIMPLE_RT_capi_h_
#define SIMPLE_RT_capi_h_

extern void SIMPLE_RT_InitializeDataMapInfo(void);

#endif                                 /* SIMPLE_RT_capi_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
