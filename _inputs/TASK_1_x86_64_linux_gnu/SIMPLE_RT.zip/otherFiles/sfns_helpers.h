#ifndef SFNS_HELPERS
#define SFNS_HELPERS

#include "simstruc.h"

#define SFN_BASIC_SETUP(S) do { \
    ssSetArrayLayoutForCodeGen(S, SS_COLUMN_MAJOR); \
    ssSetOperatingPointCompliance(S, USE_DEFAULT_OPERATING_POINT); \
    ssSetRuntimeThreadSafetyCompliance(S, RUNTIME_THREAD_SAFETY_COMPLIANCE_TRUE); \
    ssSetNumContStates(S, 0); \
    ssSetNumDiscStates(S, 0); \
    ssSetNumSampleTimes(S, 1); \
    ssSetNumRWork(S, 0); \
    ssSetNumIWork(S, 0); \
    ssSetNumPWork(S, 0); \
    ssSetNumModes(S, 0); \
    ssSetNumNonsampledZCs(S, 0); \
    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE); \
    ssSetOptions(S, (SS_OPTION_EXCEPTION_FREE_CODE | \
                     SS_OPTION_USE_TLC_WITH_ACCELERATOR | \
                     SS_OPTION_WORKS_WITH_CODE_REUSE)); \
} while(0)

#define SFN_SET_INPUT(S, id, width, type, complex) do { \
    ssSetInputPortWidth(S, id, width); \
    ssSetInputPortDataType(S, id, type); \
    ssSetInputPortComplexSignal(S, id, complex); \
    ssSetInputPortDirectFeedThrough(S, id, 1); \
    ssSetInputPortRequiredContiguous(S, id, 1); \
} while(0)

#define SFN_SET_OUTPUT(S, id, width, type, complex) do { \
    ssSetOutputPortWidth(S, id, width); \
    ssSetOutputPortDataType(S, id, type); \
    ssSetOutputPortComplexSignal(S, id, complex); \
} while(0)

#endif
