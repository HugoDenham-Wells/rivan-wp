#ifndef PLATFORM_H
#define PLATFORM_H

#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>

#include "simstruc.h"

#include "nanomodbus.h"

#define UNUSED_PARAM(x) ((x) = (x))

// Connection management
/*
void connect_tcp(int *client_connection_p, char *address, const char *port)
{
  struct addrinfo ainfo = {0};
  struct addrinfo *results;
  struct addrinfo *rp;
  int fd;

  ainfo.ai_family = AF_INET;
  ainfo.ai_socktype = SOCK_STREAM;

  int ret = getaddrinfo(address, port, &ainfo, &results);
  if (ret != 0)
  {
    *client_connection_p = 0;
    return;
  }

  for (rp = results; rp != NULL; rp = rp->ai_next)
  {
    fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
    if (fd == -1)
      continue;

    ret = connect(fd, rp->ai_addr, rp->ai_addrlen);
    if (ret == 0)
      break;

    close(fd); sf mod
  }

  freeaddrinfo(results);

  if (rp == NULL)
  {
    *client_connection_p = 0;
    return;
  }

  *client_connection_p = fd;
}
*/

// Connection management
void connect_tcp(int *client_connection_p, char *address, const char *port)
{
    struct addrinfo ainfo = {0};
    struct addrinfo *results;
    struct addrinfo *rp;
    int fd;
    
    ainfo.ai_family = AF_INET;
    ainfo.ai_socktype = SOCK_STREAM;
    
    int ret = getaddrinfo(address, port, &ainfo, &results);
    if (ret != 0)
    {
        *client_connection_p = 0;
        return;
    }
    
    for (rp = results; rp != NULL; rp = rp->ai_next)
    {
        fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (fd == -1)
            continue;
        
        // Set socket to non-blocking mode
        int flags = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);
        
        ret = connect(fd, rp->ai_addr, rp->ai_addrlen);
        if (ret == 0 || (ret == -1 && errno == EINPROGRESS))
            break;
            
        close(fd);
    }
    
    freeaddrinfo(results);
    if (rp == NULL)
    {
        *client_connection_p = 0;
        return;
    }
    
    *client_connection_p = fd;
}

int check_connecting_status(int fd)
{
    fd_set writefds;
    struct timeval tv;

    FD_ZERO(&writefds);
    FD_SET(fd, &writefds);

    tv.tv_sec = 0;
    tv.tv_usec = 0;

    int ret = select(fd + 1, NULL, &writefds, NULL, &tv);
    if (ret > 0)
    {
        if (FD_ISSET(fd, &writefds))
        {
            int so_error;
            socklen_t len = sizeof(so_error);
            getsockopt(fd, SOL_SOCKET, SO_ERROR, &so_error, &len);

            if (so_error == 0)
            {
                return 1; // Successfully connected
            }
            else if (so_error == EINPROGRESS)
            {
                return 0; // Still connecting
            }
            else
            {
                return -1; // Error occurred
            }
        }
    }
    else if (ret == 0)
    {
        return 0; // Still in progress
    }

    return -1; // Select error or unexpected condition
}

int check_disconnection_status(int fd)
{
    fd_set readfds;
    struct timeval tv;
    char buf[1];

    FD_ZERO(&readfds);
    FD_SET(fd, &readfds);

    tv.tv_sec = 0;
    tv.tv_usec = 0;

    int ret = select(fd + 1, &readfds, NULL, NULL, &tv);
    if (ret > 0)
    {
        if (FD_ISSET(fd, &readfds))
        {
            // Peek to check if there's data or disconnection
            ret = recv(fd, buf, sizeof(buf), MSG_PEEK);
            if (ret == 0)
            {
                // Peer has performed an orderly shutdown
                return -1; // Disconnected
            }
            else if (ret < 0)
            {
                if (errno == EAGAIN || errno == EWOULDBLOCK)
                {
                    // No data available but not an error
                    return 1; // Connection is still active
                }
                else
                {
                    // A real error occurred
                    return -1; // Disconnected or error
                }
            }
        }
    }
    else if (ret == 0)
    {
        // No readability event, connection is still active
        return 1;
    }
    else
    {
        // select failed
        return -1; // Error
    }

    return 1; // Connection is still active
}

void disconnect(int fd)
{
  close(fd);
  printf("Closed connection %d\n", fd);
}


// Read/write platform functions

int32_T read_fd_linux(uint8_T *buf, uint16_T count, int32_T timeout_ms, void *arg)
{
  if (!arg)
  {
    return -1;
  }

  int fd = *(int *)arg;

  uint16_T total = 0;
  while (total != count)
  {
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);

    struct timeval *tv_p = NULL;
    struct timeval tv;
    if (timeout_ms >= 0)
    {
      tv_p = &tv;
      tv.tv_sec = timeout_ms / 1000;
      tv.tv_usec = (int64_t)(timeout_ms % 1000) * 1000;
    }

    int ret = select(fd + 1, &rfds, NULL, NULL, tv_p);
    if (ret == 0)
    {
      return total;
    }

    if (ret == 1)
    {
      ssize_t r = read(fd, buf + total, 1);
      if (r == 0)
      {
        disconnect(*(int *)arg);
        return 0;
      }

      if (r < 0)
        return -1;

      total += r;
    }
    else
      return -1;
  }

  return total;
}

int32_T write_fd_linux(const uint8_T *buf, uint16_T count, int32_T timeout_ms, void *arg)
{
  int fd = *(int *)arg;

  uint16_T total = 0;
  while (total != count)
  {
    fd_set wfds;
    FD_ZERO(&wfds);
    FD_SET(fd, &wfds);

    struct timeval *tv_p = NULL;
    struct timeval tv;
    if (timeout_ms >= 0)
    {
      tv_p = &tv;
      tv.tv_sec = timeout_ms / 1000;
      tv.tv_usec = (int64_t)(timeout_ms % 1000) * 1000;
    }

    int ret = select(fd + 1, NULL, &wfds, NULL, tv_p);
    if (ret == 0)
    {
      return 0;
    }

    if (ret == 1)
    {
      ssize_t w = write(fd, buf + total, count);
      if (w == 0)
      {
        disconnect(*(int *)arg);
        return -1;
      }

      if (w <= 0)
        return -1;

      total += (int32_t)w;
    }
    else
      return -1;
  }

  return total;
}

#endif
